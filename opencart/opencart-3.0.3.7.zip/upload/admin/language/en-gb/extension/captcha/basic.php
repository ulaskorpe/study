<?php
// Heading
$_['heading_title']    = 'Basic Captcha';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified Basic Captcha!';
$_['text_edit']        = 'Edit Basic Captcha';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Basic Captcha!';