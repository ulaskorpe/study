<?php
// Heading
$_['heading_title']    = 'Sagepay Direct Card Management';

$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified Sagepay Direct Card Management module!';
$_['text_edit']        = 'Edit Sagepay Direct Card Management Module';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Sagepay Direct Card Management module!';