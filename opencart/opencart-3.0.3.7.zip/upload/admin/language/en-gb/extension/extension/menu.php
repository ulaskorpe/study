<?php
// Heading
$_['heading_title']    = 'Menu';

// Text
$_['text_success']     = 'Success: You have modified menu!';
$_['text_list']        = 'Menu List';

// Column
$_['column_name']      = 'Menu Name';
$_['column_status']    = 'Status';
$_['column_action']    = 'Action';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify menu!';